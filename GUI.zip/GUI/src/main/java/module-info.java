module com.example.gui {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires org.postgresql.jdbc;


    opens com.example.gui to javafx.fxml;
    exports com.example.gui;
    exports com.example.gui.GUI;
    opens com.example.gui.GUI to javafx.fxml;
}