package com.example.gui;

import com.example.gui.GUI.StartingScreenGUI;

import java.sql.*;

public class Connessione
{
    public static class DatabaseConnection {

        private static Connection conn = null;
        public static Connection getConnection() throws SQLException {
            //Raccolta dati
            String DB_URL = "jdbc:postgresql://localhost:5432/" + StartingScreenGUI.sceltaNome.getText();
            String USER = StartingScreenGUI.sceltaUtente.getText();
            String PASS = StartingScreenGUI.sceltaPassword.getText();

            try {
                Class.forName("org.postgresql.Driver");
                conn = DriverManager.getConnection(DB_URL, USER, PASS);
            } catch (ClassNotFoundException ex) {
                System.out.println("Driver not found");
                StartingScreenGUI.errore();
                conn.close();
                ex.printStackTrace();
            } catch (SQLException ex) {
                System.out.println("Connection failed");
                StartingScreenGUI.errore();
                conn.close();
                ex.printStackTrace();

            }
            return conn;
        }
        public static void start() {
            try {
                conn = DatabaseConnection.getConnection();
                System.out.println("Connessione riuscita");
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

        public static void stop() throws SQLException {
            try {
                conn.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
