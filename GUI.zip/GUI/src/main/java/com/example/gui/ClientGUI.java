package com.example.gui;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ClientGUI extends Application {
    private static TextField canzoneRicercata;
    private static TextField artistaRicercato;

    @Override
    public void start(Stage schermataPrincipale){

        //Creo TableView
        TableView tabella = new TableView<>();

        //Crea le colonne della tabella con il tipo di oggetto dell'attributo e il tipo di dato
        TableColumn<Canzone, String> nomeCanzone = new TableColumn<>("Canzone");
        //cerca nei metodi della classe Canzone il get corrispondente in questo caso getNomeCanzone e ne
        //attribuisce i valori (case sensitive)
        nomeCanzone.setCellValueFactory(new PropertyValueFactory<>("nomeCanzone"));
        nomeCanzone.setResizable(true);

        TableColumn<Canzone, String> nomeArtista = new TableColumn<>("Artista");
        nomeArtista.setCellValueFactory(new PropertyValueFactory<>("nomeArtista"));
        nomeArtista.setResizable(true);

        TableColumn<Canzone, Integer> anno = new TableColumn<>("Anno");
        anno.setCellValueFactory(new PropertyValueFactory<>("anno"));
        anno.setResizable(true);

        TableColumn<Canzone, String> pk = new TableColumn<>("PK");
        pk.setCellValueFactory(new PropertyValueFactory<>("Pk"));
        pk.setResizable(true);

        //crea le colonne nella tabella e inserisce quelle create sopra
        tabella.getColumns().addAll(pk,anno,nomeArtista,nomeCanzone);

        //MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM

        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(10));
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        Label canzoneLabel = new Label("Nome canzone:");
        canzoneRicercata = new TextField();
        Label artistaLabel = new Label("Nome artista:");
        artistaRicercato = new TextField();
        Button ricerca = new Button("Cerca");
        gridPane.add(canzoneLabel, 0, 0);
        gridPane.add(canzoneRicercata, 1, 0);
        gridPane.add(artistaLabel, 0, 1);
        gridPane.add(artistaRicercato, 1, 1);
        gridPane.add(ricerca,0,2);

        //CREA HBOX
        HBox hbox = new HBox();
        hbox.setSpacing(10);
        hbox.getChildren().addAll(gridPane, tabella);
        HBox.setHgrow(tabella, Priority.ALWAYS);

        //CREARE VBOX
        VBox vbox = new VBox();
        vbox.setPadding(new Insets(10));
        vbox.setSpacing(10);
        Label title = new Label("EmotionalSong");
        vbox.getChildren().addAll(title,hbox);

        //CREA SCENA
        Scene scena = new Scene(vbox, 800, 600);

        schermataPrincipale.setScene(scena);
        schermataPrincipale.setTitle("EotionalSongs");
        schermataPrincipale.setResizable(true);
        schermataPrincipale.show();


        //LISTENER PER SELEZIONE
        tabella.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) ->{
            // Estrai i dati della canzone selezionata
            if (newValue != null) {
                String Canzone = ((Canzone) newValue).getNomeCanzone();
                String Artista = ((Canzone) newValue).getNomeArtista();
                System.out.println("Canzone selezionata: " + Canzone + "  Autore: " + Artista);
            }
        });

        ricerca.setOnAction(e ->{
            // Aggiungi dati alla tabella
            eseguiQuery(tabella);
        });

    }

    public static class Canzone {
        private final String pk;
        private final String artista;
        private final String canzone;
        private final int anno;

        public Canzone(String pk, int anno, String artista, String canzone) {
            this.pk = pk;
            this.anno = anno;
            this.artista = artista;
            this.canzone = canzone;
        }

        public String getNomeCanzone() {
            return canzone;
        }

        public String getNomeArtista() {
            return artista;
        }

        public int getAnno() {
            return anno;
        }

        public String getPk(){
            return pk;
        }
    }
    private void eseguiQuery(TableView tabella) {
        try {
            // Crea una connessione al database
            Connection connection = Connessione.DatabaseConnection.getConnection();
            // Crea uno statement per eseguire la query
            Statement statement = connection.createStatement();

            // Esegui la query e ottieni il risultato
            ResultSet resultSet = statement.executeQuery("SELECT * FROM prova WHERE canzone = '" + canzoneRicercata.getText() + "'" );

            tabella.getItems().clear();
            // Aggiungi i risultati alla tabella riga per riga
            while (resultSet.next()) {
                //le stringe devono rappresentare il nome delle colonne su Postgre
                String nomeC = resultSet.getString("canzone");
                String nomeA = resultSet.getString("artista");
                int a = resultSet.getInt("anno");
                String p = resultSet.getString("pk");

                Canzone canzoni = new Canzone(p, a, nomeA, nomeC);
                tabella.getItems().add(canzoni);
                tabella.refresh();
            }

            // Chiudi la connessione
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    }

