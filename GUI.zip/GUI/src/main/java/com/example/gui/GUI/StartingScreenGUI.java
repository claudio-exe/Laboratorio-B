package com.example.gui.GUI;

import com.example.gui.ClientGUI;
import com.example.gui.Connessione;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class StartingScreenGUI extends Application {
    public static TextField sceltaNome;
    public static TextField sceltaUtente;
    public static TextField sceltaPassword;
    private static Text status;

    @Override
    public void start(Stage primaryStage) {
        // Crea elementi
        Label nomeSQL = new Label("Nome del tuo server postgresql:");
        //nomeSQL.setWrappingWidth(200);

        Label nomeUtente = new Label("Nome dell'utente:");

        Label password = new Label("Password del server:");

        sceltaNome = new TextField("");
        sceltaUtente = new TextField("");
        sceltaPassword = new TextField("");

        Label Intestazione = new Label("Compila i seguenti campi");
        Intestazione.setFont(Font.font("Arial", FontWeight.BOLD, 16));

        Button avvio = new Button("Avvia server");



        status = new Text("Connessione fallita");
        status.setVisible(false);

        // Crea il layout manager GridPane
        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(10));
        gridPane.setHgap(10);
        gridPane.setVgap(10);

        // Aggiungi il pulsante alla griglia nella cella (0, 0)
        gridPane.add(Intestazione, 0, 1);
        gridPane.add(sceltaNome,1,2);
        gridPane.add(nomeSQL, 0, 2);
        gridPane.add(sceltaUtente,1,3);
        gridPane.add(nomeUtente,0,3);
        gridPane.add(sceltaPassword, 1, 4);
        gridPane.add(password,0,4);
        gridPane.add(avvio, 4,4);
        gridPane.add(status,3,4);

        // Crea la scena e imposta la griglia come root
        Scene scene = new Scene(gridPane);

        // Imposta la scena sullo stage e mostra lo stage
        primaryStage.setScene(scene);
        primaryStage.setTitle("EmotionalSongs");
        primaryStage.setResizable(false);
        primaryStage.show();

        // Imposta la larghezza e l'altezza preferite della GridPane in modo che si adattino al contenuto
        gridPane.setPrefWidth(gridPane.getBoundsInParent().getWidth());
        gridPane.setPrefHeight(gridPane.getBoundsInParent().getHeight());

        avvio.setOnAction(e -> {
            Connessione.DatabaseConnection.start();
            primaryStage.close();
            //RicercaCanzoniGUI ricercaCanzoniGUI = new RicercaCanzoniGUI();
            ClientGUI clientGUI = new ClientGUI();
            try {
                clientGUI.start(new Stage());
            } catch (Exception ex) {
                throw new RuntimeException(ex);
            }
        });
    }

    public static void errore(){
        fadingGUI fading = new fadingGUI();
        status.setVisible(true);
        fading.displayText(status);
    }

}