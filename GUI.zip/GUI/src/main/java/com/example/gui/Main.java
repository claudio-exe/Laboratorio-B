package com.example.gui;

import com.example.gui.GUI.StartingScreenGUI;
import javafx.application.Application;

public class Main {
    public static void main(String[] args) throws Exception {
        Application.launch(StartingScreenGUI.class, args);
        Connessione.DatabaseConnection.stop();
    }
}
