package com.example.gui;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class test extends Application {

    @Override
    public void start(Stage primaryStage) {

        // Crea la TableView e aggiungi le colonne e i dati
        TableView<Person> tableView = new TableView<>();
        // Crea le colonne della TableView
        TableColumn<Person, String> firstNameCol = new TableColumn<>("First Name");
        TableColumn<Person, String> lastNameCol = new TableColumn<>("Last Name");

        // Imposta le PropertyValueFactory per le colonne
        firstNameCol.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        lastNameCol.setCellValueFactory(new PropertyValueFactory<>("lastName"));

        // Aggiungi le colonne alla TableView
        tableView.getColumns().addAll(firstNameCol, lastNameCol);
        ObservableList<Person> data = FXCollections.observableArrayList(
                new Person("John", "Doe"),
                new Person("Jane", "Doe"),
                new Person("Bob", "Smith")
        );
        tableView.setItems(data);

        // Crea la GridPane e aggiungi i nodi
        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(10));
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        Label nameLabel = new Label("Nome:");
        TextField nameTextField = new TextField();
        Label lastNameLabel = new Label("Cognome:");
        TextField lastNameTextField = new TextField();
        gridPane.add(nameLabel, 0, 0);
        gridPane.add(nameTextField, 1, 0);
        gridPane.add(lastNameLabel, 0, 1);
        gridPane.add(lastNameTextField, 1, 1);

        // Crea l'HBox per affiancare la TableView e la GridPane
        HBox hbox = new HBox();
        hbox.setSpacing(10);
        hbox.getChildren().addAll(tableView, gridPane);
        HBox.setHgrow(tableView, Priority.ALWAYS);

        // Crea la VBox per contenere l'HBox e un titolo
        VBox vbox = new VBox();
        vbox.setPadding(new Insets(10));
        vbox.setSpacing(10);
        Label title = new Label("Esempio di TableView e GridPane");
        vbox.getChildren().addAll(title, hbox);

        Scene scene = new Scene(vbox, 800, 600);
        primaryStage.setScene(scene);
        primaryStage.setTitle("TableView e GridPane");
        primaryStage.show();

        // Aggiungi un listener per la selezione delle righe
        tableView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            // Estrai i dati della persona selezionata
            if (newValue != null) {
                String firstName = newValue.getFirstName();
                String lastName = newValue.getLastName();
                System.out.println("Persona selezionata: " + firstName + " " + lastName);
            }
        });
    }

    public static void main(String[] args) {
        launch(args);
    }

    // Classe di esempio per rappresentare una persona
    public static class Person {
        private String firstName;
        private String lastName;

        public Person(String firstName, String lastName) {
            this.firstName = firstName;
            this.lastName = lastName;
        }

        public String getFirstName() {
            return firstName;
        }

        public void setFirstName(String firstName) {
            this.firstName = firstName;
        }

        public String getLastName() {
            return lastName;
        }

        public void setLastName(String lastName) {
            this.lastName = lastName;
        }
    }
}