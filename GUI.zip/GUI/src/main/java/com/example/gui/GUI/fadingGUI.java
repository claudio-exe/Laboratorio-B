package com.example.gui.GUI;

import javafx.animation.FadeTransition;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.text.Text;
import javafx.util.Duration;

public class fadingGUI {

    public void displayText(Text text) {
        //cose
        text.setVisible(true);
        // Crea una transizione di fading
        FadeTransition fadeTransition = new FadeTransition(Duration.seconds(1), text);
        fadeTransition.setFromValue(1.0);
        fadeTransition.setToValue(0.0);

        // Crea un evento per gestire la fine della transizione di fading
        EventHandler<ActionEvent> eventHandler = new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                // Rimuovi il testo dalla GridPane
                text.setVisible(true);
            }
        };

        // Aggiungi una callback alla fine della transizione di fading per rimuovere il testo dalla GridPane
        fadeTransition.setOnFinished(eventHandler);

        // Mostra la scritta per 3 secondi
        text.setOpacity(1.0);
        Timeline timeline = new Timeline(new javafx.animation.KeyFrame(Duration.seconds(1.5), e -> {
            text.setVisible(true);
            // Avvia la transizione di fading
            fadeTransition.play();
        }));
        timeline.play();
    }
}


