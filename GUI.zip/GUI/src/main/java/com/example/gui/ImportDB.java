package com.example.gui;

import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.Statement;
import org.postgresql.copy.CopyManager;
import org.postgresql.core.BaseConnection;

public class ImportDB {
    private static final String nomeTabella = "";
    public void start() throws Exception {
        String query = leggiQueryDaFile("nomefile");
        Connection connection = Connessione.DatabaseConnection.getConnection();
        Statement statement = connection.createStatement();
        statement.execute(query);
        //MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
        String nomeFile = "dat.scv";
        FileReader file = new FileReader(nomeFile);
        // Crea un oggetto CopyManager per eseguire il comando COPY
        CopyManager copyManager = new CopyManager((BaseConnection) connection);
        // Esegue il comando COPY per importare i dati dal file CSV nella tabella
        copyManager.copyIn("COPY " + nomeTabella + " FROM STDIN WITH DELIMITER ';' CSV HEADER", file);
        //MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
    }

    public static String leggiQueryDaFile(String nomeFile) throws Exception {
        BufferedReader reader = new BufferedReader(new FileReader(nomeFile));
        StringBuilder stringBuilder = new StringBuilder();
        String linea;

        while ((linea = reader.readLine()) != null) {
            stringBuilder.append(linea).append("\n");
        }

        reader.close();
        return stringBuilder.toString();
    }
}

